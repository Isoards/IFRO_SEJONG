
import os
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
import hashlib

class EncryptionManager:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(EncryptionManager, cls).__new__(cls)
        return cls._instance

    def __init__(self, key_directory='.', private_key_password=None):
        if hasattr(self, '_initialized'):
            return
            
        if not private_key_password:
            raise ValueError("A password for the private key is required for initialization.")

        self.key_directory = Path(key_directory)
        self.private_key_path = self.key_directory / 'private_key.pem'
        self.public_key_path = self.key_directory / 'public_key.pem'
        self._private_key_password = private_key_password.encode('utf-8') if isinstance(private_key_password, str) else private_key_password

        self._initialize_keys()
        self._initialized = True

    def _initialize_keys(self):
        self.key_directory.mkdir(parents=True, exist_ok=True)
        if not self.private_key_path.exists() or not self.public_key_path.exists():
            self._generate_and_save_keys()
        
        self._load_keys()

    def _generate_and_save_keys(self):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        public_key = private_key.public_key()

        pem_private_key = private_key.private_bytes(
           encoding=serialization.Encoding.PEM,
           format=serialization.PrivateFormat.PKCS8,
           encryption_algorithm=serialization.BestAvailableEncryption(self._private_key_password)
        )
        with open(self.private_key_path, 'wb') as f:
            f.write(pem_private_key)

        pem_public_key = public_key.public_bytes(
           encoding=serialization.Encoding.PEM,
           format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        with open(self.public_key_path, 'wb') as f:
            f.write(pem_public_key)

    def _load_keys(self):
        with open(self.private_key_path, "rb") as key_file:
            self._private_key = serialization.load_pem_private_key(
                key_file.read(),
                password=self._private_key_password,
            )
        with open(self.public_key_path, "rb") as key_file:
            self._public_key = serialization.load_pem_public_key(
                key_file.read(),
            )

    def encrypt(self, message: str) -> bytes:
        return self._public_key.encrypt(
            message.encode('utf-8'),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

    def decrypt(self, encrypted_message: bytes) -> str:
        return self._private_key.decrypt(
            encrypted_message,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        ).decode('utf-8')

    @staticmethod
    def hash_string(input_string: str, salt: str = None) -> str:
        if salt:
            input_string = salt + input_string
        
        sha512 = hashlib.sha512()
        sha512.update(input_string.encode('utf-8'))
        return sha512.hexdigest()

