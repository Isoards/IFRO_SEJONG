from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

def generate_key_pair():
    """
    Generates an RSA-2048 key pair.

    Returns:
        A tuple containing the private and public keys.
    """
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()
    return private_key, public_key

def encrypt_message(public_key, message: str) -> bytes:
    """
    Encrypts a message using the public key.

    Args:
        public_key: The public key to use for encryption.
        message: The message to be encrypted.

    Returns:
        The encrypted message.
    """
    encrypted_message = public_key.encrypt(
        message.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_message

def decrypt_message(private_key, encrypted_message: bytes) -> str:
    """
    Decrypts a message using the private key.

    Args:
        private_key: The private key to use for decryption.
        encrypted_message: The message to be decrypted.

    Returns:
        The decrypted message.
    """
    decrypted_message = private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_message.decode('utf-8')
