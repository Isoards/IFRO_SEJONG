import hashlib

def hash_string(input_string: str) -> str:
    """
    Hashes the input string using SHA-512.

    Args:
        input_string: The string to be hashed.

    Returns:
        The SHA-512 hash of the input string.
    """
    sha512 = hashlib.sha512()
    sha512.update(input_string.encode('utf-8'))
    return sha512.hexdigest()
